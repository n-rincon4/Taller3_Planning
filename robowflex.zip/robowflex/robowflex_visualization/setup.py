from setuptools import setup

setup(
    name = 'robowflex_visualization',
    version = '1.3.0',
    description = 'Robowflex: Blender Visualization Tools',
    author = 'Zachary Kingston',
    author_email = 'zak@rice.edu',
    packages = ['robowflex_visualization'],
)
